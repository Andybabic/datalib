Contains detailed results of all the classifiers that we have used in the paper.

```
  Binary_Classification.csv           --> Contains the results of the Binary classification task.
  Multi_Label_Classification.csv      --> Contains the results of the Multi-label classification task. 
  Counterspeech Video Statistics.csv  --> Contains details such as video title, URL, Number of likes etc. for the videos selected for Annotation.
```
